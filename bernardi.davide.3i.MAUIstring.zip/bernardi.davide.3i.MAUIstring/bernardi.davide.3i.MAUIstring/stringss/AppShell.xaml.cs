﻿namespace stringss;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
